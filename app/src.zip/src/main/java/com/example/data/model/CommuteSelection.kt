package com.example.data.model

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

data class CommuteSelection(
    val date: LocalDate = LocalDate.now(),
    val direction: String = "Township → Plant",
    val commuteWindow: String = "07:00 – 07:30",
    val pickupZone: String = "EMs",
    val destinationZone: String = "FFL Plant Main Gate"
) {
    val formattedDate: String
        get() = try {
            date.format(DateTimeFormatter.ofPattern("EEEE, dd MMM", Locale.getDefault()))
        } catch (e: Exception) {
            "Monday, 31 Aug"
        }

    val isoDate: String
        get() = date.format(DateTimeFormatter.ISO_LOCAL_DATE)
}
