package com.example.data.repository

import com.example.data.model.Co2Record
import com.example.data.model.SystemConfig
import com.example.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AdminRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    fun getCo2RecordsFlow(): Flow<List<Co2Record>> = callbackFlow {
        val listener = db.collection("co2Records")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val records = snapshot?.documents?.mapNotNull { it.toObject(Co2Record::class.java) } ?: emptyList()
                trySend(records)
            }
        awaitClose { listener.remove() }
    }

    fun getSystemConfigFlow(): Flow<SystemConfig> = callbackFlow {
        val listener = db.collection("systemConfig").document("sustainability")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(SystemConfig())
                    return@addSnapshotListener
                }
                val config = snapshot?.toObject(SystemConfig::class.java) ?: SystemConfig()
                trySend(config)
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateSustainabilityConfig(baselineKm: Double, co2Factor: Double): Result<Unit> {
        return try {
            val updates = mapOf(
                "baselineDistanceKm" to baselineKm,
                "co2FactorKgPerKm" to co2Factor
            )
            db.collection("systemConfig").document("sustainability")
                .set(updates, com.google.firebase.firestore.SetOptions.merge())
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getAllUsersFlow(): Flow<List<User>> = callbackFlow {
        val listener = db.collection("users")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val users = snapshot?.documents?.mapNotNull { doc ->
                    val raw = doc.toObject(User::class.java)
                    raw?.copy(
                        role = raw.effectiveRole,
                        currentMode = raw.effectiveMode
                    )
                } ?: emptyList()
                trySend(users)
            }
        awaitClose { listener.remove() }
    }

    suspend fun setUserAdminRole(targetUid: String, makeAdmin: Boolean): Result<Unit> {
        return try {
            val currentUid = auth.currentUser?.uid ?: throw Exception("Not authenticated.")
            if (targetUid.isBlank()) throw Exception("Target user ID cannot be empty.")

            // Read current user to verify ADMIN role
            val currentDoc = db.collection("users").document(currentUid).get().await()
            val currentUserRole = currentDoc.getString("role")?.uppercase() ?: ""
            if (currentUserRole != User.ROLE_ADMIN) {
                throw Exception("Access Denied: Only administrators can grant or revoke admin access.")
            }

            // Self-demotion protection
            if (targetUid == currentUid && !makeAdmin) {
                throw Exception("Self-demotion blocked: You cannot remove your own Administrator access.")
            }

            // Read target user
            val targetDoc = db.collection("users").document(targetUid).get().await()
            if (!targetDoc.exists()) {
                throw Exception("Target employee user document does not exist.")
            }

            val newRole = if (makeAdmin) User.ROLE_ADMIN else User.ROLE_USER

            // Update ONLY the role field - preserve currentMode, defaultRolePreference, and profile data intact
            db.collection("users").document(targetUid).update("role", newRole).await()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
