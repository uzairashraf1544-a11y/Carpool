package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.User
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class UserRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    fun getCurrentUserFlow(): Flow<User?> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = db.collection("users").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    logFirestoreError("getCurrentUserFlow", "users/$uid", uid, error)
                    trySend(null)
                    return@addSnapshotListener
                }
                val rawUser = snapshot?.toObject(User::class.java)
                val user = rawUser?.let {
                    it.copy(
                        role = it.effectiveRole,
                        currentMode = it.effectiveMode
                    )
                }
                if (BuildConfig.DEBUG) {
                    Log.d("FirestoreDebug", "USER_EMITTED | uid: $uid | role: ${user?.role} | mode: ${user?.currentMode}")
                }
                trySend(user)
            }

        awaitClose { listener.remove() }
    }

    suspend fun getCurrentUser(): User? {
        val uid = auth.currentUser?.uid ?: return null
        return try {
            val doc = db.collection("users").document(uid).get().await()
            val rawUser = doc.toObject(User::class.java) ?: return null
            rawUser.copy(
                role = rawUser.effectiveRole,
                currentMode = rawUser.effectiveMode
            )
        } catch (e: Exception) {
            logFirestoreError("getCurrentUser", "users/$uid", uid, e)
            null
        }
    }

    suspend fun updateCurrentMode(newMode: String): Result<Unit> {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.e("FirestoreDebug", "MODE_SWITCH_FAILURE | No authenticated user")
            return Result.failure(IllegalStateException("No authenticated Firebase user"))
        }

        val uid = currentUser.uid
        val modeUpper = newMode.uppercase()
        if (modeUpper != User.MODE_PASSENGER && modeUpper != User.MODE_DRIVER) {
            return Result.failure(IllegalArgumentException("Invalid travel mode: $newMode"))
        }

        val ref = db.collection("users").document(uid)

        return try {
            Log.d("FirestoreDebug", "MODE_SWITCH_START | uid=$uid | requestedMode=$modeUpper")
            ref.update("currentMode", modeUpper).await()
            Log.d("FirestoreDebug", "MODE_SWITCH_FIRESTORE_SUCCESS | uid=$uid | mode=$modeUpper")
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is FirebaseFirestoreException) {
                Log.e(
                    "FirestoreDebug",
                    "MODE_SWITCH_FIRESTORE_FAILURE | path=users/$uid | uid=$uid | code=${e.code} | message=${e.message}",
                    e
                )
            } else {
                Log.e("FirestoreDebug", "MODE_SWITCH_FAILURE", e)
            }
            Result.failure(e)
        }
    }

    suspend fun updateUserProfile(
        name: String,
        phone: String,
        department: String,
        townshipLocation: String,
        defaultRolePreference: String,
        defaultDriverSeats: Int
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(Exception("User not authenticated."))
        val prefUpper = if (defaultRolePreference.uppercase() == User.MODE_DRIVER) User.MODE_DRIVER else User.MODE_PASSENGER
        val updates = mapOf(
            "name" to name.trim(),
            "phone" to phone.trim(),
            "department" to department,
            "townshipLocation" to townshipLocation,
            "defaultRolePreference" to prefUpper,
            "defaultDriverSeats" to defaultDriverSeats
        )
        return try {
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("updateUserProfile", "users/$uid", uid, e)
            Result.failure(e)
        }
    }

    suspend fun setMuteSchedule(muteUntilTimestamp: Long): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(Exception("User not authenticated."))
        return try {
            db.collection("users").document(uid).update("muteUntilTimestamp", muteUntilTimestamp).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("setMuteSchedule", "users/$uid", uid, e)
            Result.failure(e)
        }
    }

    private fun logFirestoreError(opName: String, path: String, uid: String, e: Exception) {
        if (BuildConfig.DEBUG && e is FirebaseFirestoreException) {
            Log.d("FirestoreDebug", "Op: $opName | Path: $path | UID: $uid | Code: ${e.code} | Msg: ${e.message}")
        }
    }
}
