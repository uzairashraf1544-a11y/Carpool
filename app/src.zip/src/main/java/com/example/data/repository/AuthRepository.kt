package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.User
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

sealed interface AuthState {
    data object Loading : AuthState
    data class Authenticated(val firebaseUser: FirebaseUser, val userProfile: User?) : AuthState
    data object Unauthenticated : AuthState
}

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    val currentUserUid: String?
        get() = auth.currentUser?.uid

    private fun isDefaultAdminEmail(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        val clean = email.trim().lowercase()
        return clean == "uzair.ashraf.gemini@gmail.com" || clean == "uzair.ashraf@fatima-group.com"
    }

    val authStateFlow: Flow<AuthState> = callbackFlow {
        trySend(AuthState.Loading)
        if (BuildConfig.DEBUG) {
            Log.d("AuthDebug", "AUTH_INIT_START")
        }

        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val firebaseUser = firebaseAuth.currentUser
            if (firebaseUser != null) {
                if (BuildConfig.DEBUG) {
                    Log.d("AuthDebug", "AUTH_STATE: AUTHENTICATED | uid: ${firebaseUser.uid} | email: ${firebaseUser.email}")
                }
                db.collection("users").document(firebaseUser.uid).get()
                    .addOnSuccessListener { doc ->
                        val rawUser = doc.toObject(User::class.java)
                        val isAdminEmail = isDefaultAdminEmail(firebaseUser.email)
                        val userProfile = rawUser?.let {
                            it.copy(
                                role = if (isAdminEmail) User.ROLE_ADMIN else it.effectiveRole,
                                currentMode = it.effectiveMode
                            )
                        }
                        // Ensure Admin role in Firestore if admin email
                        if (isAdminEmail && rawUser != null && rawUser.role != User.ROLE_ADMIN) {
                            db.collection("users").document(firebaseUser.uid).update("role", User.ROLE_ADMIN)
                        }
                        trySend(AuthState.Authenticated(firebaseUser, userProfile))
                    }
                    .addOnFailureListener {
                        trySend(AuthState.Authenticated(firebaseUser, null))
                    }
            } else {
                if (BuildConfig.DEBUG) {
                    Log.d("AuthDebug", "AUTH_STATE: UNAAUTHENTICATED")
                }
                trySend(AuthState.Unauthenticated)
            }
        }

        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun login(emailInput: String, passwordInput: String): Result<User> {
        return try {
            val input = emailInput.trim()
            val email = if (!input.contains("@")) "$input@ffl.com" else input
            val authResult = auth.signInWithEmailAndPassword(email, passwordInput).await()
            val uid = authResult.user?.uid ?: throw Exception("Invalid user ID.")

            val userDoc = db.collection("users").document(uid).get().await()
            val rawUser = userDoc.toObject(User::class.java) ?: throw Exception("User profile not found in database.")

            val isAdminEmail = isDefaultAdminEmail(email)
            val assignedRole = if (isAdminEmail) User.ROLE_ADMIN else rawUser.effectiveRole

            if (isAdminEmail && rawUser.role != User.ROLE_ADMIN) {
                db.collection("users").document(uid).update("role", User.ROLE_ADMIN).await()
            }

            val user = rawUser.copy(
                role = assignedRole,
                currentMode = rawUser.effectiveMode
            )

            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun register(
        name: String,
        email: String,
        password: String,
        employeeId: String,
        department: String,
        modePreference: String,
        townshipLocation: String,
        defaultSeats: Int
    ): Result<User> {
        return try {
            val safeMode = if (modePreference.uppercase() == User.MODE_DRIVER) User.MODE_DRIVER else User.MODE_PASSENGER
            val cleanEmail = email.trim()
            val isAdminEmail = isDefaultAdminEmail(cleanEmail)

            val authResult = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
            val uid = authResult.user?.uid ?: throw Exception("Failed to register user.")

            val newUser = User(
                uid = uid,
                name = name.trim(),
                email = cleanEmail,
                employeeId = employeeId.trim(),
                department = department,
                role = if (isAdminEmail) User.ROLE_ADMIN else User.ROLE_USER,
                phone = "",
                townshipLocation = townshipLocation,
                currentMode = safeMode,
                defaultRolePreference = safeMode,
                defaultDriverSeats = defaultSeats,
                isPasswordChanged = true
            )

            db.collection("users").document(uid).set(newUser).await()
            Result.success(newUser)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signInWithGoogleCredential(credential: AuthCredential): Result<User> {
        return try {
            val authResult = auth.signInWithCredential(credential).await()
            val firebaseUser = authResult.user ?: throw Exception("Google sign in failed.")
            val uid = firebaseUser.uid
            val userEmail = firebaseUser.email ?: ""
            val isAdminEmail = isDefaultAdminEmail(userEmail)

            val userDoc = db.collection("users").document(uid).get().await()
            if (userDoc.exists()) {
                val rawUser = userDoc.toObject(User::class.java) ?: throw Exception("Profile parsing error.")
                if (isAdminEmail && rawUser.role != User.ROLE_ADMIN) {
                    db.collection("users").document(uid).update("role", User.ROLE_ADMIN).await()
                }
                val user = rawUser.copy(
                    role = if (isAdminEmail) User.ROLE_ADMIN else rawUser.effectiveRole,
                    currentMode = rawUser.effectiveMode
                )
                Result.success(user)
            } else {
                val draftUser = User(
                    uid = uid,
                    name = firebaseUser.displayName ?: "",
                    email = userEmail,
                    role = if (isAdminEmail) User.ROLE_ADMIN else User.ROLE_USER
                )
                Result.success(draftUser)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun completeGoogleProfile(
        employeeId: String,
        department: String,
        townshipLocation: String,
        defaultMode: String,
        defaultSeats: Int,
        phone: String
    ): Result<User> {
        val firebaseUser = auth.currentUser ?: return Result.failure(Exception("No authenticated Google user."))
        val uid = firebaseUser.uid
        val userEmail = firebaseUser.email ?: ""
        val isAdminEmail = isDefaultAdminEmail(userEmail)
        val safeMode = if (defaultMode.uppercase() == User.MODE_DRIVER) User.MODE_DRIVER else User.MODE_PASSENGER

        val newUser = User(
            uid = uid,
            name = firebaseUser.displayName ?: "Employee",
            email = userEmail,
            employeeId = employeeId.trim(),
            department = department,
            role = if (isAdminEmail) User.ROLE_ADMIN else User.ROLE_USER,
            phone = phone.trim(),
            townshipLocation = townshipLocation,
            currentMode = safeMode,
            defaultRolePreference = safeMode,
            defaultDriverSeats = defaultSeats,
            isPasswordChanged = true
        )

        return try {
            db.collection("users").document(uid).set(newUser).await()
            Result.success(newUser)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun changePassword(newPassword: String): Result<Unit> {
        return try {
            val user = auth.currentUser ?: throw Exception("No authenticated user.")
            user.updatePassword(newPassword).await()

            val uid = user.uid
            db.collection("users").document(uid).update("isPasswordChanged", true).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        return try {
            auth.sendPasswordResetEmail(email.trim()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout() {
        if (BuildConfig.DEBUG) {
            Log.d("AuthDebug", "SIGN_OUT_CALLED | user: ${auth.currentUser?.email}")
        }
        auth.signOut()
    }
}
