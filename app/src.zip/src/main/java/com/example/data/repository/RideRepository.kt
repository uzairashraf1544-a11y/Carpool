package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.Ride
import com.example.data.model.RideRequest
import com.example.data.model.Co2Record
import com.example.data.model.SystemConfig
import com.example.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RideRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun hasActiveDriverRide(driverId: String, date: String): Boolean {
        return try {
            val rideId = "${driverId}_$date"
            val doc = db.collection("rides").document(rideId).get().await()
            if (!doc.exists()) return false
            val ride = doc.toObject(Ride::class.java) ?: return false
            ride.status in listOf(Ride.STATUS_AVAILABLE, Ride.STATUS_PARTIALLY_FULL, Ride.STATUS_FULL, Ride.STATUS_RIDE_STARTED)
        } catch (e: Exception) {
            logFirestoreError("hasActiveDriverRide", "rides/${driverId}_$date", driverId, e)
            false
        }
    }

    // ----------------------------------------------------
    // DRIVER ACTIONS
    // ----------------------------------------------------

    suspend fun createOrUpdateDriverAvailability(
        user: User,
        date: String,
        commuteWindow: String,
        direction: String,
        pickupZone: String,
        destinationZone: String,
        totalSeats: Int
    ): Result<Ride> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        if (totalSeats < 1) return Result.failure(Exception("Total seats must be at least 1."))

        return try {
            val rideId = "${user.uid}_$date"
            val rideRef = db.collection("rides").document(rideId)

            val existingDoc = rideRef.get().await()
            val existingRide = if (existingDoc.exists()) existingDoc.toObject(Ride::class.java) else null

            val acceptedPassengers = existingRide?.acceptedPassengerIds ?: emptyList()
            val availableSeats = (totalSeats - acceptedPassengers.size).coerceAtLeast(0).coerceAtMost(totalSeats)

            val status = when {
                availableSeats == 0 -> Ride.STATUS_FULL
                acceptedPassengers.isNotEmpty() -> Ride.STATUS_PARTIALLY_FULL
                else -> Ride.STATUS_AVAILABLE
            }

            val ride = Ride(
                rideId = rideId,
                driverId = user.uid,
                driverName = user.name,
                driverPhone = user.phone,
                driverDepartment = user.department,
                date = date,
                commuteWindow = commuteWindow,
                direction = direction,
                pickupZone = pickupZone,
                destinationZone = destinationZone,
                totalSeats = totalSeats,
                availableSeats = availableSeats,
                acceptedPassengerIds = acceptedPassengers,
                status = status
            )

            rideRef.set(ride).await()
            Result.success(ride)
        } catch (e: Exception) {
            logFirestoreError("createOrUpdateDriverAvailability", "rides/${user.uid}_$date", currentUid, e)
            Result.failure(e)
        }
    }

    suspend fun setDriverOffline(driverId: String, date: String): Result<Unit> {
        return try {
            val rideId = "${driverId}_$date"
            db.collection("rides").document(rideId).update("status", Ride.STATUS_OFFLINE).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("setDriverOffline", "rides/${driverId}_$date", driverId, e)
            Result.failure(e)
        }
    }

    fun getDriverTodayRideFlow(driverId: String, date: String): Flow<Ride?> = callbackFlow {
        val rideId = "${driverId}_$date"
        val listener = db.collection("rides").document(rideId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    logFirestoreError("getDriverTodayRideFlow", "rides/$rideId", driverId, error)
                    trySend(null)
                    return@addSnapshotListener
                }
                val ride = snapshot?.toObject(Ride::class.java)
                trySend(ride)
            }
        awaitClose { listener.remove() }
    }

    fun getIncomingRequestsForDriverFlow(driverId: String, date: String): Flow<List<RideRequest>> = callbackFlow {
        val listener = db.collection("rideRequests")
            .whereEqualTo("driverId", driverId)
            .whereEqualTo("date", date)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    logFirestoreError("getIncomingRequestsForDriverFlow", "rideRequests", driverId, error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val reqs = snapshot?.documents?.mapNotNull { it.toObject(RideRequest::class.java) } ?: emptyList()
                trySend(reqs)
            }
        awaitClose { listener.remove() }
    }

    suspend fun acceptRideRequestTransaction(requestId: String, rideId: String, passengerId: String): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        return try {
            val rideRef = db.collection("rides").document(rideId)
            val requestRef = db.collection("rideRequests").document(requestId)

            db.runTransaction { transaction ->
                val rideSnap = transaction.get(rideRef)
                if (!rideSnap.exists()) {
                    throw FirebaseFirestoreException("Ride no longer exists.", FirebaseFirestoreException.Code.NOT_FOUND)
                }

                val currentAvailable = rideSnap.getLong("availableSeats") ?: 0L
                val currentStatus = rideSnap.getString("status") ?: ""
                val currentPassengers = (rideSnap.get("acceptedPassengerIds") as? List<*>)?.mapNotNull { it.toString() } ?: emptyList()

                if (currentAvailable <= 0 || currentStatus == Ride.STATUS_FULL || currentStatus == Ride.STATUS_OFFLINE) {
                    throw FirebaseFirestoreException("Sorry, this driver's seats are currently full.", FirebaseFirestoreException.Code.ABORTED)
                }

                if (currentPassengers.contains(passengerId)) {
                    transaction.update(requestRef, "status", RideRequest.STATUS_ACCEPTED)
                    return@runTransaction
                }

                val newAvailable = (currentAvailable - 1L).coerceAtLeast(0L)
                val newPassengers = currentPassengers + passengerId
                val newStatus = if (newAvailable == 0L) Ride.STATUS_FULL else Ride.STATUS_PARTIALLY_FULL

                transaction.update(rideRef, mapOf(
                    "availableSeats" to newAvailable,
                    "acceptedPassengerIds" to newPassengers,
                    "status" to newStatus
                ))
                transaction.update(requestRef, "status", RideRequest.STATUS_ACCEPTED)
            }.await()

            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("acceptRideRequestTransaction", "rides/$rideId", currentUid, e)
            Result.failure(e)
        }
    }

    suspend fun rejectRideRequest(requestId: String): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        return try {
            db.collection("rideRequests").document(requestId).update("status", RideRequest.STATUS_REJECTED).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("rejectRideRequest", "rideRequests/$requestId", currentUid, e)
            Result.failure(e)
        }
    }

    suspend fun startRide(rideId: String): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        return try {
            db.collection("rides").document(rideId).update("status", Ride.STATUS_RIDE_STARTED).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("startRide", "rides/$rideId", currentUid, e)
            Result.failure(e)
        }
    }

    suspend fun finishRide(rideId: String): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        return try {
            val rideRef = db.collection("rides").document(rideId)
            val rideDoc = rideRef.get().await()
            val ride = rideDoc.toObject(Ride::class.java)

            db.collection("rides").document(rideId).update("status", Ride.STATUS_COMPLETED).await()

            if (ride != null && ride.acceptedPassengerIds.isNotEmpty()) {
                val passengerCount = ride.acceptedPassengerIds.size
                val configDoc = db.collection("systemConfig").document("sustainability").get().await()
                val config = configDoc.toObject(SystemConfig::class.java) ?: SystemConfig()

                val avoidedKm = passengerCount * config.baselineDistanceKm
                val co2Saved = avoidedKm * config.co2FactorKgPerKm
                val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

                val co2Record = Co2Record(
                    recordId = "${rideId}_co2",
                    rideId = rideId,
                    driverId = ride.driverId,
                    driverName = ride.driverName,
                    driverDepartment = ride.driverDepartment,
                    passengerCount = passengerCount,
                    baselineDistanceKm = config.baselineDistanceKm,
                    totalAvoidedKm = avoidedKm,
                    co2SavedKg = co2Saved,
                    monthYear = monthYear,
                    timestamp = System.currentTimeMillis()
                )
                db.collection("co2Records").document(co2Record.recordId).set(co2Record).await()
            }

            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("finishRide", "rides/$rideId", currentUid, e)
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // PASSENGER ACTIONS
    // ----------------------------------------------------

    fun getAvailableDriversFlow(date: String, directionFilter: String, windowFilter: String): Flow<List<Ride>> = callbackFlow {
        val listener = db.collection("rides")
            .whereEqualTo("date", date)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    logFirestoreError("getAvailableDriversFlow", "rides", "ALL", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val rides = snapshot?.documents?.mapNotNull { it.toObject(Ride::class.java) } ?: emptyList()
                val filtered = rides.filter { ride ->
                    (ride.status == Ride.STATUS_AVAILABLE || ride.status == Ride.STATUS_PARTIALLY_FULL) &&
                            ride.availableSeats > 0 &&
                            (directionFilter == "All" || ride.direction == directionFilter) &&
                            (windowFilter == "All" || ride.commuteWindow == windowFilter)
                }
                trySend(filtered)
            }
        awaitClose { listener.remove() }
    }

    fun getPassengerRequestsFlow(passengerId: String, date: String): Flow<List<RideRequest>> = callbackFlow {
        val listener = db.collection("rideRequests")
            .whereEqualTo("passengerId", passengerId)
            .whereEqualTo("date", date)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    logFirestoreError("getPassengerRequestsFlow", "rideRequests", passengerId, error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val reqs = snapshot?.documents?.mapNotNull { it.toObject(RideRequest::class.java) } ?: emptyList()
                trySend(reqs)
            }
        awaitClose { listener.remove() }
    }

    suspend fun requestRideFromDriver(passenger: User, ride: Ride): Result<RideRequest> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        return try {
            val requestId = "${passenger.uid}_${ride.rideId}"
            val request = RideRequest(
                requestId = requestId,
                rideId = ride.rideId,
                driverId = ride.driverId,
                driverName = ride.driverName,
                passengerId = passenger.uid,
                passengerName = passenger.name,
                passengerPhone = passenger.phone,
                passengerDepartment = passenger.department,
                pickupZone = ride.pickupZone,
                destinationZone = ride.destinationZone,
                commuteWindow = ride.commuteWindow,
                date = ride.date,
                status = RideRequest.STATUS_REQUESTED,
                requestedAt = System.currentTimeMillis()
            )
            db.collection("rideRequests").document(requestId).set(request).await()
            Result.success(request)
        } catch (e: Exception) {
            logFirestoreError("requestRideFromDriver", "rideRequests/$passenger.uid_${ride.rideId}", currentUid, e)
            Result.failure(e)
        }
    }

    suspend fun cancelPassengerRequest(requestId: String): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: return Result.failure(Exception("Not authenticated."))
        return try {
            db.collection("rideRequests").document(requestId).update("status", RideRequest.STATUS_CANCELLED).await()
            Result.success(Unit)
        } catch (e: Exception) {
            logFirestoreError("cancelPassengerRequest", "rideRequests/$requestId", currentUid, e)
            Result.failure(e)
        }
    }

    private fun logFirestoreError(opName: String, path: String, uid: String, e: Exception) {
        if (BuildConfig.DEBUG && e is FirebaseFirestoreException) {
            Log.d("FirestoreDebug", "Op: $opName | Path: $path | UID: $uid | Code: ${e.code} | Msg: ${e.message}")
        }
    }
}
