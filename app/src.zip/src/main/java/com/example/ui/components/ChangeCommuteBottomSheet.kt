package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CommuteSelection
import com.example.data.model.MasterData
import com.example.ui.theme.*
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangeCommuteBottomSheet(
    initialSelection: CommuteSelection,
    onDismiss: () -> Unit,
    onApply: (CommuteSelection) -> Unit
) {
    var selectedDate by remember { mutableStateOf(initialSelection.date) }
    var selectedDirection by remember { mutableStateOf(initialSelection.direction) }
    var selectedWindow by remember { mutableStateOf(initialSelection.commuteWindow) }
    var selectedPickup by remember { mutableStateOf(initialSelection.pickupZone) }
    var selectedDestination by remember { mutableStateOf(initialSelection.destinationZone) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CHANGE COMMUTE",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryDark,
                    letterSpacing = 0.5.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Rounded.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. DATE SECTION
            SectionLabel("DATE")
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SelectableChip(
                    text = "Today",
                    isSelected = selectedDate == LocalDate.now(),
                    onClick = { selectedDate = LocalDate.now() }
                )
                SelectableChip(
                    text = "Tomorrow",
                    isSelected = selectedDate == LocalDate.now().plusDays(1),
                    onClick = { selectedDate = LocalDate.now().plusDays(1) }
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 2. DIRECTION SECTION
            SectionLabel("DIRECTION")
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SelectableChip(
                    text = "Township → Plant",
                    isSelected = selectedDirection == "Township → Plant",
                    onClick = { selectedDirection = "Township → Plant" }
                )
                SelectableChip(
                    text = "Plant → Township",
                    isSelected = selectedDirection == "Plant → Township",
                    onClick = { selectedDirection = "Plant → Township" }
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 3. COMMUTE WINDOW SECTION
            SectionLabel("COMMUTE WINDOW")
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                MasterData.COMMUTE_WINDOWS.forEach { window ->
                    val isSel = selectedWindow == window.name
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) PrimaryLight else SurfaceVariant)
                            .border(1.dp, if (isSel) Primary else Color.Transparent, RoundedCornerShape(12.dp))
                            .clickable { selectedWindow = window.name }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = window.name,
                            color = if (isSel) PrimaryDark else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 4. PICKUP ZONE SECTION
            SectionLabel("PICKUP ZONE")
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MasterData.TOWNSHIP_LOCATIONS.forEach { loc ->
                    SelectableChip(
                        text = loc,
                        isSelected = selectedPickup == loc,
                        onClick = { selectedPickup = loc }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 5. DESTINATION SECTION
            SectionLabel("DESTINATION")
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                MasterData.PLANT_LOCATIONS.forEach { loc ->
                    val isSel = selectedDestination == loc
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) PrimaryLight else SurfaceVariant)
                            .border(1.dp, if (isSel) Primary else Color.Transparent, RoundedCornerShape(12.dp))
                            .clickable { selectedDestination = loc }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = loc,
                            color = if (isSel) PrimaryDark else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // BOTTOM ACTIONS: Cancel | Apply Commute
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) {
                    Text("Cancel", color = TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        val newSelection = CommuteSelection(
                            date = selectedDate,
                            direction = selectedDirection,
                            commuteWindow = selectedWindow,
                            pickupZone = selectedPickup,
                            destinationZone = selectedDestination
                        )
                        onApply(newSelection)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Primary, contentColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) {
                    Text("Apply Commute", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SectionLabel(title: String) {
    Text(
        text = title,
        fontSize = 12.5.sp,
        fontWeight = FontWeight.Bold,
        color = PrimaryDark,
        letterSpacing = 0.5.sp
    )
}

@Composable
private fun SelectableChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) PrimaryDark else SurfaceVariant)
            .border(1.dp, if (isSelected) PrimaryDark else Outline, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (isSelected) Color.White else TextPrimary,
            fontSize = 13.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
