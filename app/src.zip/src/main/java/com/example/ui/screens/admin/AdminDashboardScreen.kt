package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.data.repository.AdminRepository
import com.example.ui.components.ErrorContainer
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    user: User,
    onNavigateBack: () -> Unit,
    adminRepository: AdminRepository = remember { AdminRepository() }
) {
    if (!user.isAdmin()) {
        Box(
            modifier = Modifier.fillMaxSize().background(Background).padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            ErrorContainer(message = "Access Denied. Administrator privileges required.")
        }
        return
    }

    val coroutineScope = rememberCoroutineScope()
    val co2Records by adminRepository.getCo2RecordsFlow().collectAsState(initial = emptyList())
    val systemConfig by adminRepository.getSystemConfigFlow().collectAsState(initial = com.example.data.model.SystemConfig())
    val allUsers by adminRepository.getAllUsersFlow().collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) } // 0: Overview, 1: Users, 2: Analytics, 3: Settings
    val tabs = listOf("Overview", "Users", "Analytics", "Settings")

    var baselineKmText by remember { mutableStateOf(systemConfig.baselineDistanceKm.toString()) }
    var co2FactorText by remember { mutableStateOf(systemConfig.co2FactorKgPerKm.toString()) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    var targetUserForRoleChange by remember { mutableStateOf<User?>(null) }
    var isPromotingTarget by remember { mutableStateOf(true) }

    LaunchedEffect(systemConfig) {
        baselineKmText = systemConfig.baselineDistanceKm.toString()
        co2FactorText = systemConfig.co2FactorKgPerKm.toString()
    }

    // Calculations
    val totalRides = co2Records.size
    val totalPassengers = co2Records.sumOf { it.passengerCount }
    val totalAvoidedKm = co2Records.sumOf { it.totalAvoidedKm }
    val totalCo2SavedKg = co2Records.sumOf { it.co2SavedKg }

    val filteredUsers = remember(allUsers, searchQuery) {
        if (searchQuery.isBlank()) allUsers else {
            allUsers.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.email.contains(searchQuery, ignoreCase = true) ||
                        it.employeeId.contains(searchQuery, ignoreCase = true) ||
                        it.department.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Admin Module", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Mobility & Sustainability Management", fontSize = 14.sp, color = TextSecondary)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(PrimaryDark)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("ADMIN", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tab Row
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 0.dp,
            containerColor = Surface,
            contentColor = Primary,
            modifier = Modifier.clip(RoundedCornerShape(14.dp))
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 14.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        statusMessage?.let { msg ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SuccessContainer),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Text(msg, color = Success, modifier = Modifier.padding(12.dp), fontSize = 13.5.sp)
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTab) {
                // ----------------------------------------------------
                // TAB 0: OVERVIEW
                // ----------------------------------------------------
                0 -> {
                    Text("PRIMARY KPIs", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = PrimaryDark, letterSpacing = 0.5.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KpiCard("Registered Users", "${allUsers.size}", Icons.Rounded.Groups, Primary, Modifier.weight(1f))
                        KpiCard("Completed Rides", "$totalRides", Icons.Rounded.DirectionsCar, PrimaryMedium, Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KpiCard("Avoided Distance", String.format(Locale.US, "%.1f km", totalAvoidedKm), Icons.Rounded.Route, Info, Modifier.weight(1f))
                        KpiCard("CO₂ Saved", String.format(Locale.US, "%.1f kg", totalCo2SavedKg), Icons.Rounded.Eco, Success, Modifier.weight(1f))
                    }
                }

                // ----------------------------------------------------
                // TAB 1: USERS (PROMOTION & DEMOTION)
                // ----------------------------------------------------
                1 -> {
                    Text("USER MANAGEMENT", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = PrimaryDark, letterSpacing = 0.5.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search Employees (Name, Email, ID, Dept)") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    filteredUsers.forEach { emp ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).border(1.dp, Outline.copy(alpha = 0.7f), RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = Surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(emp.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Box(
                                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (emp.isAdmin()) PrimaryVeryLight else SurfaceVariant).padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(emp.role, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (emp.isAdmin()) PrimaryDark else TextSecondary)
                                    }
                                }
                                Text("ID: ${emp.employeeId} • Dept: ${emp.department}", fontSize = 13.sp, color = TextSecondary)
                                Text("Email: ${emp.email} • Mode: ${emp.currentMode}", fontSize = 13.sp, color = TextTertiary)

                                Spacer(modifier = Modifier.height(10.dp))

                                if (emp.uid == user.uid) {
                                    Text("Current Admin (Self)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Primary)
                                } else {
                                    if (!emp.isAdmin()) {
                                        Button(
                                            onClick = {
                                                targetUserForRoleChange = emp
                                                isPromotingTarget = true
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.height(38.dp)
                                        ) {
                                            Text("Make Admin", fontSize = 13.sp)
                                        }
                                    } else {
                                        OutlinedButton(
                                            onClick = {
                                                targetUserForRoleChange = emp
                                                isPromotingTarget = false
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Error),
                                            modifier = Modifier.height(38.dp)
                                        ) {
                                            Text("Remove Admin Access", fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // ----------------------------------------------------
                // TAB 2: ANALYTICS
                // ----------------------------------------------------
                2 -> {
                    Text("SUSTAINABILITY ANALYTICS", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = PrimaryDark, letterSpacing = 0.5.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)),
                        colors = CardDefaults.cardColors(containerColor = Surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Total Avoided Trips: $totalPassengers", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Total Avoided Distance: ${String.format(Locale.US, "%.1f km", totalAvoidedKm)}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Total CO₂ Saved: ${String.format(Locale.US, "%.2f kg", totalCo2SavedKg)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primary)
                        }
                    }
                }

                // ----------------------------------------------------
                // TAB 3: SETTINGS
                // ----------------------------------------------------
                3 -> {
                    Text("SUSTAINABILITY PARAMETERS", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = PrimaryDark, letterSpacing = 0.5.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)),
                        colors = CardDefaults.cardColors(containerColor = Surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                value = baselineKmText,
                                onValueChange = { baselineKmText = it },
                                label = { Text("Baseline Distance per Trip (Km)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = co2FactorText,
                                onValueChange = { co2FactorText = it },
                                label = { Text("CO₂ Factor (kg CO₂ / km)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    val km = baselineKmText.toDoubleOrNull() ?: 3.0
                                    val factor = co2FactorText.toDoubleOrNull() ?: 0.12
                                    coroutineScope.launch {
                                        val res = adminRepository.updateSustainabilityConfig(km, factor)
                                        res.onSuccess { statusMessage = "Parameters updated!" }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(46.dp)
                            ) {
                                Text("Update Parameters")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Role Promotion / Demotion Confirmation Dialog
    targetUserForRoleChange?.let { targetUser ->
        val titleText = if (isPromotingTarget) "Grant Administrator Access" else "Remove Administrator Access"
        val bodyText = if (isPromotingTarget) {
            "Grant administrator access to ${targetUser.name}?\n\nThis user will gain access to administrative functions and management data."
        } else {
            "Remove administrator access from ${targetUser.name}?\n\nThis user will no longer have administrative privileges."
        }
        val confirmButtonText = if (isPromotingTarget) "Make Admin" else "Remove Admin Access"

        AlertDialog(
            onDismissRequest = { targetUserForRoleChange = null },
            title = { Text(titleText) },
            text = { Text(bodyText) },
            confirmButton = {
                Button(
                    onClick = {
                        val makeAdmin = isPromotingTarget
                        val targetUid = targetUser.uid
                        val targetName = targetUser.name
                        targetUserForRoleChange = null
                        coroutineScope.launch {
                            val res = adminRepository.setUserAdminRole(targetUid, makeAdmin)
                            res.onSuccess {
                                statusMessage = if (makeAdmin) "$targetName has been granted Administrator access." else "Administrator access has been removed from $targetName."
                            }.onFailure { err ->
                                statusMessage = err.message ?: "Role update failed."
                            }
                        }
                    }
                ) {
                    Text(confirmButtonText)
                }
            },
            dismissButton = {
                TextButton(onClick = { targetUserForRoleChange = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(115.dp).clip(RoundedCornerShape(18.dp)).border(1.dp, Outline.copy(alpha = 0.7f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = Surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, fontSize = 12.5.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
    }
}
